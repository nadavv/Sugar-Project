# -*- coding: utf-8 -*-
"""
Created on Mon Jul 30 14:38:03 2018

@author: opher
"""

# =============================================================================
# parameters for comparisons:
#     number of days for trainings
#     time for train in each day
#     time for predition
#     
#     lstm amount of cells
#     type of optimizer - NOT
#     loss function - NOT
#     Learning Rate
#     Number of Epoches
#     Activation Function
#     
#     which value for results evaluation:
#         max difference
#         mean difference
# =============================================================================